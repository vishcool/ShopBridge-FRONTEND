export class User {
    userName:string;
    password:string;
    admin:boolean=false;
}